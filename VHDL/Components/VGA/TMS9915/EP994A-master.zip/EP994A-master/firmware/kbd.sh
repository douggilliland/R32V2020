../memloader/memloader -k $1

