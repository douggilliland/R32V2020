xas99.py -b -R -L diskdsr.lst diskdsr.asm
