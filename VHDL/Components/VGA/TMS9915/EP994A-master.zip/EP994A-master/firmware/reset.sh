../memloader/memloader 100008 cpu_reset_on.bin 
../memloader/memloader 100008 cpu_reset_off.bin 
