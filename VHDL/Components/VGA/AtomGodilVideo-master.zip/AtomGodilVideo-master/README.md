AtomGodilVideo
==============

New Video Adapter for Acorn Atom implemented in a GODIL FPGA

See the Wiki for the latest documentation:
https://github.com/hoglet67/AtomGodilVideo/wiki

See the stardot.org.uk thread for support:
http://www.stardot.org.uk/forums/viewtopic.php?f=44&t=7320

-- Dave

